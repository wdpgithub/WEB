import { Component } from '@angular/core';
import {
  IonicPage,
  NavController,
  NavParams,
  ViewController,
  LoadingController,
  ToastController
} from 'ionic-angular';
import { RestProvider } from '../../providers/rest/rest';
import { Storage } from '@ionic/storage';
import { BaseUI } from '../../common/baseUI';

/**
 * Generated class for the LoginPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
export class LoginPage extends BaseUI {
  mobile: any;
  password: any;
  errorMessage: any;

  constructor(public navCtrl: NavController,
    public navParams: NavParams,
    public rest: RestProvider,
    public viewCtrl: ViewController,
    public loadingCtrl: LoadingController,
    public toastCtrl:ToastController,
    private storage: Storage) {
      super();
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad LoginPage');
  }
  dismiss() {
    this.viewCtrl.dismiss();
  }

  gologin() {
    let loading = super.showLoading(this.loadingCtrl,"登录中...");
    this.rest.login(this.mobile,this.password).subscribe(f=>{
        if(f["Status"]=="OK"){
        //处理登录成功的页面跳转
        //你也可以存储接口返回的 token（用户是否真实 app=>安全协议）
        this.storage.set('UserId', f["UserId"]);
        loading.dismiss();
        this.dismiss();
      }else{
        loading.dismiss();
        super.showToast(this.toastCtrl,f["StatusContent"])
      }
    },error=>this.errorMessage=<any>error)


  }

}
